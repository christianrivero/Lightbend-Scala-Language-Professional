define-class-parameters

# Exercise 2 > Define class parameters

In the course video recordings, the instructor uses a `man e` command in the sbt interactive session to display exercise instructions. 

The LSL-P-lightbend-scala-language-professional.zip you downloaded does not contain the `man e` exercise instructions. 

In this course version, the exercise instructions are included in Academy alongside the exercise introduction and exercise review video recordings.

Please refer to the Academy instructions in order to complete the exercise.