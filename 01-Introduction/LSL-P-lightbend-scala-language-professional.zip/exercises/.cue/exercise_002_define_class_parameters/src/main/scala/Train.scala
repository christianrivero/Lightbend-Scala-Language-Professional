/*
 * Copyright © 2012 - 2016 Lightbend, Inc. All rights reserved.
 */

class Train(number: Int)
